/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject3.Client;

import com.mycompany.mavenproject3.Server.Chatter;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Vector;

/**
 *
 * @author hieua
 */
public interface ChatClient3IF extends Remote{

	public void messageFromServer(String message) throws RemoteException;
        
        public void messageFromClientToClient(String fromcChatter,String message) throws RemoteException;

	public void updateUserList(String[] currentUsers) throws RemoteException;
        public void updateUserList1(Vector<Chatter> chatters) throws RemoteException;
	
}
